//package PackageName;
//
//import java.io.File;
//import java.io.IOException;
//import java.net.MalformedURLException;
//import java.net.URL;
//import java.util.concurrent.TimeUnit;
//
//import org.apache.log4j.Logger;
//import org.apache.log4j.PropertyConfigurator;
//import org.openqa.selenium.remote.DesiredCapabilities;
//import org.testng.annotations.BeforeSuite;
//import org.testng.annotations.Test;
//
//import io.appium.java_client.android.AndroidDriver;
//import io.appium.java_client.android.AndroidElement;
//import io.appium.java_client.remote.MobileCapabilityType;
//import io.appium.java_client.remote.MobilePlatform;
//
//
//public class Base {
//
//	Logger Log = Logger.getLogger(Logger.class.getName());
//	
//	
//	public static AndroidDriver<AndroidElement> capabilities() throws MalformedURLException {
//		File f = new File("src/test/java");
//		File fs = new File(f,"ApiDemos-debug.apk");
//		
//		DesiredCapabilities dcap = new DesiredCapabilities();
//		dcap.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
//		dcap.setCapability(MobileCapabilityType.DEVICE_NAME, "Nexus 5X API 28");
//		dcap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT,"100");
//		dcap.setCapability(MobileCapabilityType.APP, fs.getAbsolutePath());
//		AndroidDriver<AndroidElement> driver = new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"),dcap);
//		return driver;
//
//	}
//	@Test
//	public void setDriver() throws MalformedURLException {
//		PropertyConfigurator.configure("Log4j.properties");
//		AndroidDriver<AndroidElement> driver = capabilities();
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
//		Home home = new Home();
//		Log.info("Clicking on the preferences option");
//		home.clcikOnPreferences.click();
//		Preferences preferences = new Preferences(driver);
//		preferences.clcikOnPreferenceDependencies.click();
//		preferences.clickOnWifiOptionsCheckbox.click();
//		preferences.clickOnWifiOptions.click();
//		preferences.enterWifiDetails.sendKeys("hello");
//		preferences.clickOnOK.click();
//		preferences.uncheckWifiCheckBox.click();
//
//	}
//
//
//	@BeforeSuite
//	public void startAppium() throws IOException, InterruptedException {
//		Runtime.getRuntime().exec("cmd /c start C:\\startappium.bat");
//		Thread.sleep(8000);
//	}
//
//
//
//
//}
