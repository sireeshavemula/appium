package PackageName;

import static io.appium.java_client.touch.LongPressOptions.longPressOptions;
import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static java.time.Duration.ofSeconds;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;


public class AppTest 
{
   // @Test
   // public static void shouldAnswerWithTrue()
    //{
       //System.out.println("check");
    //}
    
    @Test
    public static void letsTry() throws MalformedURLException {
		// TODO Auto-generated method stub
		AndroidDriver<AndroidElement> driver = capabilities();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);  
		driver.findElementByXPath("//android.widget.TextView[@text='Preference']").click();
		driver.findElementByXPath("//android.widget.TextView[@text='3. Preference dependencies']").click();
		driver.findElementById("android:id/checkbox").click();
		driver.findElementByXPath("//android.widget.TextView[@text='WiFi settings']").click();
		driver.findElementByClassName("android.widget.EditText").sendKeys("hello");
		//AndroidElement wifi = driver.findElementById("android:id/edit");
		//wifi.click();
		//wifi.sendKeys("hello");
		driver.findElementByXPath("//android.widget.Button[@text='OK']").click();
		//driver.findElementByAndroidUIAutomator("attribute("value")");
		driver.findElementById("android:id/checkbox").click();
		driver.navigate().back();
		driver.navigate().back();
		driver.findElementByAndroidUIAutomator("text(\"Views\")").click();
		//validate clickable feature or any property values
		//driver.findElementsByAndroidUIAutomator("new UiSelector().clickable(true)");
		 int getSize = driver.findElementsByAndroidUIAutomator("new UiSelector().clickable(true)").size();
	    System.out.println(getSize);
	    AndroidElement tapExpandable = driver.findElementByXPath("//android.widget.TextView[@text='Expandable Lists']");
	    tapExpandable.click();
	    driver.findElementByXPath("//android.widget.TextView[@text='1. Custom Adapter']").click();
	    AndroidElement e =  driver.findElementByXPath("//android.widget.TextView[@text='People Names']");
	    TouchAction press = new TouchAction(driver)
				.longPress(longPressOptions()
				.withElement(element(e)))
				.waitAction(waitOptions(ofSeconds(1)))
				.release()
				.perform();
	    
	  AndroidElement getValue =  driver.findElementsByClassName("android.widget.TextView").get(0);
	  String value =  getValue.getText();
	  System.out.println(value);
	  driver.navigate().back();
	  driver.navigate().back();
	  driver.navigate().back();
	  driver.findElementByAndroidUIAutomator("text(\"Date Widgets\")").click();
	  driver.findElementByAndroidUIAutomator("text(\"2. Inline\")").click();
	  driver.findElementByXPath("//*[@content-desc = '9']").click();
	  //swiping from one element to another
	 AndroidElement initial = driver.findElementByXPath("//*[@content-desc = '15']");
	  AndroidElement swipeto = driver.findElementByXPath("//*[@content-desc = '45']");
	  TouchAction tc = new TouchAction(driver)
				.longPress(longPressOptions()
				.withElement(element(initial)))
				.waitAction(waitOptions(ofSeconds(1))).moveTo(element(swipeto))
				.release()
				.perform();
	  //driver.pressKey(new KeyEvent(AndroidKey.BACK));
	  //driver.pressKey(new KeyEvent(AndroidKey.BACK));
	  
	  
	  driver.navigate().back();
	  driver.navigate().back();
	  
	  //appium is not supporting scrolling anymore 
	  //we can only use scroll using android api

	  //driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"WebView\"));");
	  driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Drag and Drop\"));").click();
	  //drag and drop
	 AndroidElement source = driver.findElementsByClassName("android.view.View").get(0);
	 AndroidElement destination = driver.findElementsByClassName("android.view.View").get(1);
	 TouchAction t = new TouchAction(driver)
	  			.longPress(longPressOptions()
	  			.withElement(element(source)))
	  			.waitAction(waitOptions(ofSeconds(2))).moveTo(element(destination))
	  			.release()
	  			.perform();
		 
	 // to know the current activity : each page in an app is an activity
	 System.out.println(driver.currentActivity());
	 //to know the orientation
	 System.out.println(driver.getOrientation());
	 // to know the context such as native, hybrid or webview
	 System.out.println(driver.getContext());
	 // to check if the device is locked
	 System.out.println(driver.isDeviceLocked());
	 //to hide the keyboard in certain pages
	//driver.hideKeyboard();

	}
    
    public static AndroidDriver<AndroidElement> capabilities() throws MalformedURLException {
    	File f = new File("src/test/java");
		File fs = new File(f,"ApiDemos-debug.apk");
		
		DesiredCapabilities dcap = new DesiredCapabilities();
		dcap.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
		dcap.setCapability(MobileCapabilityType.DEVICE_NAME, "Nexus 5X API 28");
		dcap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT,"100");
		dcap.setCapability(MobileCapabilityType.APP, fs.getAbsolutePath());
		AndroidDriver<AndroidElement> driver = new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"),dcap);
        return driver;
    	
    }
      

@BeforeSuite
public void startAppium() throws IOException, InterruptedException {
	Runtime.getRuntime().exec("cmd /c start C:\\startappium.bat");
	Thread.sleep(8000);
}
}
