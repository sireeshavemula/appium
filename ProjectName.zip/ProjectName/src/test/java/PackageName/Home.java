//package PackageName;
//
//import java.net.MalformedURLException;
//import java.util.concurrent.TimeUnit;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.PageFactory;
//import org.testng.annotations.Test;
//
//import Utility.Hooks;
//import io.appium.java_client.AppiumDriver;
//import io.appium.java_client.MobileElement;
//import io.appium.java_client.android.AndroidDriver;
//import io.appium.java_client.android.AndroidElement;
//import io.appium.java_client.pagefactory.AndroidFindBy;
//import io.appium.java_client.pagefactory.AppiumFieldDecorator;
//
//
//public class Home extends Base {
//	
//	private WebDriver driver;
//	
//	public Home() throws MalformedURLException {	
//		//this.driver = Hooks.getDriver();
//    PageFactory.initElements(driver, this);	
//	}
//	
//	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Preference']")
//	public WebElement clcikOnPreferences;
//	
//	
//	public void clickOnPreferences(WebDriver driver) {
//		clcikOnPreferences.click();
//	}
//}
