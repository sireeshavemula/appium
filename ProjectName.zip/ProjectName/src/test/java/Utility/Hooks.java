package Utility;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeSuite;

import cucumber.api.java.After;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

public class Hooks {
	
	private static Hooks instance;
    private static WebDriver driver;
    private static Thread CLOSE_DRIVER = new Thread() {
    @Override
    public void run() {
        driver.close();
    }
    };
    
    static {
        Runtime.getRuntime().addShutdownHook(CLOSE_DRIVER);
    }
	
    private Hooks() throws MalformedURLException
    {
    		File f = new File("src/test/java");
   		File fs = new File(f,"ApiDemos-debug.apk");
    		
    		DesiredCapabilities dcap = new DesiredCapabilities();
    		dcap.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
    		dcap.setCapability(MobileCapabilityType.DEVICE_NAME, "Nexus 5X API 28");
    		dcap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT,"100");
   		dcap.setCapability(MobileCapabilityType.APP, fs.getAbsolutePath());
    		 driver = new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"),dcap);
 }
//	@Before("@web")
//	public void setUp()
//	{
//		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//drivers//chromedriver.exe");
//		driver= new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//	}
//	
	//@Before("@appium")
	public void setUpAppium() throws MalformedURLException
	{
		File f = new File("src/test/java");
		File fs = new File(f,"ApiDemos-debug.apk");
		
		DesiredCapabilities dcap = new DesiredCapabilities();
		dcap.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
		dcap.setCapability(MobileCapabilityType.DEVICE_NAME, "Nexus 5X API 28");
		dcap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT,"100");
		dcap.setCapability(MobileCapabilityType.APP, fs.getAbsolutePath());
		 driver = new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"),dcap);
		//driver = new AndroidDriver<WebElement>(new URL("http://0.0.0.0:4723/wd/hub"), cap);
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
//	
	@After
	public void tearDown()
	{
		driver.quit();
	}
	
	public static Hooks getTestingBase() throws MalformedURLException {
        if (instance == null) {
            instance = new Hooks();
        }
        return instance;

    }
	
	public static WebDriver getDriver() throws MalformedURLException
	{
		 return getTestingBase().driver;
	}
	
	//@BeforeSuite
	public void startAppium() throws IOException, InterruptedException {
		Runtime.getRuntime().exec("cmd /c start C:\\startappium.bat");
		Thread.sleep(8000);
	}

}
