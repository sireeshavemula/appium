package StepDefinationFiles;

import java.net.MalformedURLException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;


import Utility.Hooks;
import Utility.TestingBase;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;


public class apiDemoStepDefination {
	
private WebDriver driver;

	
	 public apiDemoStepDefination() throws MalformedURLException {
		 this.driver = TestingBase.getDriver();
	 }
	
	@Given("I open the app API Demo in my mobile")
	public void I_open_the_app_API_Demo_in_my_mobile() {
		WebElement home = driver.findElement(By.xpath("//android.widget.TextView[@text='Preference']"));
		home.click();
		System.out.println("print given");
		
	}
	
	@When("I click on the preferences and then on preference dependecies")
	public void I_click_on_the_preferences_and_then_on_preference_dependecies() {
		System.out.println("print when");
		
	}
	
	@When("I check the Wifi checkbox to click on Wifi settings")
	public void I_check_the_Wifi_checkbox_to_click_on_Wifi_settings() {
		System.out.println("print when");
	}
	
	@Then("I can setup the wifi")
	public void I_can_setup_the_wifi() {
		System.out.println("print then");
	}

}
